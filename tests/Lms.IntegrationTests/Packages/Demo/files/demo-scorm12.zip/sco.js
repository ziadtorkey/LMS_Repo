// LMS demo SCO runtime (authored by the LMS team). Finds the API the platform provides, never contacts anything else.
var LmsDemo = (function () {
  var V2004 = false;
  var api = null, ready = false;
  function find() {
    // The platform defines the API on this window; a classic parent walk is tried as well and its SecurityError is tolerated.
    api = V2004 ? window.API_1484_11 : window.API;
    if (!api) { try { var w = window.parent; api = V2004 ? w.API_1484_11 : w.API; } catch (e) { api = null; } }
    return api;
  }
  function call(name12, name2004) { return V2004 ? api[name2004] : api[name12]; }
  function init() {
    var status = document.querySelector('[data-testid="sco-api-status"]');
    if (!find()) { status.textContent = 'API NOT found'; return false; }
    status.textContent = 'API found (' + (V2004 ? 'SCORM 2004' : 'SCORM 1.2') + ')';
    ready = String(call('LMSInitialize', 'Initialize')('')) === 'true';
    return ready;
  }
  function get(key) { return String(call('LMSGetValue', 'GetValue')(key) || ''); }
  function set(key, value) { return call('LMSSetValue', 'SetValue')(key, String(value)); }
  function commit() { return call('LMSCommit', 'Commit')(''); }
  function finish() { return call('LMSFinish', 'Terminate')(''); }
  return {
    page1: function () {
      if (!init()) { return; }
      // A returning learner continues on page 2 (the position is kept in suspend_data).
      if (get('cmi.suspend_data') === 'page=2') { location.replace('page2.html'); return; }
      document.getElementById('next').addEventListener('click', function () {
        set('cmi.suspend_data', 'page=2');
        set(V2004 ? 'cmi.completion_status' : 'cmi.core.lesson_status', 'incomplete');
        commit();
        // The commit travels to the platform asynchronously; the next page asks the server for its state when it loads.
        setTimeout(function () { location.href = 'page2.html'; }, 600);
      });
    },
    page2: function () {
      if (!init()) { return; }
      document.getElementById('finish').addEventListener('click', function () {
        var score = Number(document.getElementById('score').value);
        if (V2004) {
          set('cmi.score.raw', score); set('cmi.score.min', 0); set('cmi.score.max', 100); set('cmi.score.scaled', score / 100);
          set('cmi.completion_status', 'completed'); set('cmi.success_status', score >= 60 ? 'passed' : 'failed');
        } else {
          set('cmi.core.score.raw', score); set('cmi.core.score.min', 0); set('cmi.core.score.max', 100);
          set('cmi.core.lesson_status', score >= 60 ? 'passed' : 'failed');
        }
        set('cmi.suspend_data', 'page=2');
        commit();
        finish();
        document.getElementById('result').textContent = 'Finished with score ' + score;
        document.getElementById('finish').disabled = true;
      });
    }
  };
})();